"""
Copyright (c) 2023, Zscaler Inc.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"""

from typing import List, Optional

from zscaler.api_client import APIClient
from zscaler.request_executor import RequestExecutor
from zscaler.types import APIResult
from zscaler.utils import format_url
from zscaler.zpa.models.customer_dr_tool import CustomerDRToolVersion


class CustomerDRToolVersionAPI(APIClient):
    """
    A client object for the Customer DR Tool Version resource.
    """

    def __init__(self, request_executor, config):
        super().__init__()
        self._request_executor: RequestExecutor = request_executor
        customer_id = config["client"].get("customerId")
        self._zpa_base_endpoint = f"/zpa/mgmtconfig/v1/admin/customers/{customer_id}"

    def list_latest_dr_tool_versions(self, query_params: Optional[dict] = None) -> APIResult[List[CustomerDRToolVersion]]:
        """
        Fetch latest the Customer Support DR Tool Versions sorted by latest filter.

        Args:
            query_params {dict}: Map of query parameters for the request.

                ``[query_params.page_size]`` {str}: Specifies the page size.
                    If not provided, the default page size is 20. The max page size is 500.

                ``[query_params.page_num]`` {str}: Specifies the page number.

                ``[query_params.search]`` {str}: Search string for filtering results.

        Returns:
            :obj:`Tuple`: A tuple containing (list of CustomerDRToolVersion instances, Response, error)

        Example:
            Fetch latest the Customer Support DR Tool Versions sorted by latest filter

            >>> fetch_tools, _, err = client.zpa.customer_dr_tool.list_latest_dr_tool_versions()
            ... if err:
            ...     print(f"Error fetching latest Customer Support DR Tool Versions: {err}")
            ...     return
            ... print(f"Total Customer Support DR Tool Versions found: {len(fetch_tools)}")
            ... for tool in fetch_tools:
            ...     print(tool.as_dict())

            Client-side filtering with JMESPath:

            The response object supports client-side filtering and
            projection via ``resp.search(expression)``.  See the
            `JMESPath documentation <https://jmespath.org/>`_ for
            expression syntax.

        """
        http_method = "get".upper()
        api_url = format_url(f"""
            {self._zpa_base_endpoint}
            /customerDRToolVersion
        """)

        query_params = query_params or {}

        request, error = self._request_executor.create_request(http_method, api_url, params=query_params)
        if error:
            return (None, None, error)

        response, error = self._request_executor.execute(request, CustomerDRToolVersion)
        if error:
            return (None, response, error)

        try:
            result = []
            for item in response.get_results():
                result.append(CustomerDRToolVersion(self.form_response_body(item)))
        except Exception as error:
            return (None, response, error)
        return (result, response, None)
