"""
Copyright (c) 2023, Zscaler Inc.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"""

from typing import List, Optional

from zscaler.api_client import APIClient
from zscaler.request_executor import RequestExecutor
from zscaler.types import APIResult
from zscaler.utils import format_url
from zscaler.zpa.enrollment_certificates import EnrollmentCertificateAPI
from zscaler.zpa.models.app_connector_groups import AppConnectorGroup


class AppConnectorGroupAPI(APIClient):
    """
    A Client object for the App Connector Groups resource.
    """

    def __init__(self, request_executor, config):
        super().__init__()
        self._request_executor: RequestExecutor = request_executor
        customer_id = config["client"].get("customerId")
        self._zpa_base_endpoint = f"/zpa/mgmtconfig/v1/admin/customers/{customer_id}"
        self._enrollment_certificates = EnrollmentCertificateAPI(request_executor, config)

    def list_connector_groups(self, query_params: Optional[dict] = None) -> APIResult[List[AppConnectorGroup]]:
        """
        Enumerates connector groups in your organization with pagination.
        A subset of connector groups can be returned that match a supported
        filter expression or query.

        Args:
            query_params {dict}: Map of query parameters for the request.

                ``[query_params.page]`` {str}: Specifies the page number.

                ``[query_params.page_size]`` {str}: Specifies the page size.
                    If not provided, the default page size is 20. The max page size is 500.

                ``[query_params.search]`` {str}: Search string for filtering results.
                ``[query_params.microtenant_id]`` {str}: The unique identifier of the microtenant of ZPA tenant.

        Returns:
            :obj:`Tuple`: A tuple containing (list of AppConnectorGroup instances, Response, error)

        Examples:
            >>> group_list, _, err = client.zpa.app_connector_groups.list_connector_groups(
            ... query_params={'search': 'ConnectorGRP01', 'page': '1', 'page_size': '100'})
            ... if err:
            ...     print(f"Error listing app connector group: {err}")
            ...     return
            ... print(f"Total app connector groups found: {len(group_list)}")
            ... for group in groups:
            ...     print(group.as_dict())

            Client-side filtering with JMESPath:

            The response object supports client-side filtering and
            projection via ``resp.search(expression)``.  See the
            `JMESPath documentation <https://jmespath.org/>`_ for
            expression syntax.

        """
        http_method = "get".upper()
        api_url = format_url(f"""
            {self._zpa_base_endpoint}
            /appConnectorGroup
        """)

        query_params = query_params or {}
        microtenant_id = query_params.get("microtenant_id", None)
        if microtenant_id:
            query_params["microtenantId"] = microtenant_id

        request, error = self._request_executor.create_request(http_method, api_url, params=query_params)
        if error:
            return (None, None, error)

        response, error = self._request_executor.execute(request, AppConnectorGroup)
        if error:
            return (None, response, error)

        try:
            result = []
            for item in response.get_results():
                result.append(AppConnectorGroup(self.form_response_body(item)))
        except Exception as error:
            return (None, response, error)
        return (result, response, None)

    def list_connector_groups_summary(self, query_params: Optional[dict] = None) -> APIResult[List[AppConnectorGroup]]:
        """
        Retrieves all configured app connector groups Name and IDs

        Args:
            query_params {dict}: Map of query parameters for the request.

                ``[query_params.page]`` {str}: Specifies the page number.

                ``[query_params.page_size]`` {int}: Specifies the page size.
                    If not provided, the default page size is 20. The max page size is 500.

                ``[query_params.search]`` {str}: The search string used to support search by features and fields for the API.

                ``[query_params.microtenant_id]`` {str}: The unique identifier of the microtenant of ZPA tenant.

        Returns:
            :obj:`Tuple`: A tuple containing (list of AppConnectorGroups instances, Response, error)

        Examples:
            >>> group_list, _, err = client.zpa.app_connector_groups.list_connector_groups_summary(
            ... query_params={'search': 'Group01', 'page': '1', 'page_size': '100'})
            ... if err:
            ...     print(f"Error listing app connector groups: {err}")
            ...     return
            ... print(f"Total app connector groups found: {len(group_list)}")
            ... for group in group_list:
            ...     print(group.as_dict())

            Client-side filtering with JMESPath:

            The response object supports client-side filtering and
            projection via ``resp.search(expression)``.  See the
            `JMESPath documentation <https://jmespath.org/>`_ for
            expression syntax.

        """
        http_method = "get".upper()
        api_url = format_url(f"""
            {self._zpa_base_endpoint}
            /appConnectorGroup/summary
        """)

        query_params = query_params or {}
        microtenant_id = query_params.get("microtenant_id", None)
        if microtenant_id:
            query_params["microtenantId"] = microtenant_id

        request, error = self._request_executor.create_request(http_method, api_url, params=query_params)
        if error:
            return (None, None, error)

        response, error = self._request_executor.execute(request, AppConnectorGroup)
        if error:
            return (None, response, error)

        try:
            result = []
            for item in response.get_results():
                result.append(AppConnectorGroup(self.form_response_body(item)))
        except Exception as error:
            return (None, response, error)
        return (result, response, None)

    def get_connector_group(self, group_id: str, query_params: Optional[dict] = None) -> APIResult[AppConnectorGroup]:
        """
        Fetches a specific connector group by ID.

        Args:
            group_id (str): The unique identifier for the connector group.
            query_params (dict, optional): Map of query parameters for the request.
                ``[query_params.microtenant_id]`` {str}: The microtenant ID, if applicable.

        Returns:
            :obj:`Tuple`: A tuple containing (AppConnectorGroup instance, Response, error).

        Examples:
            >>> fetched_group, _, err = client.zpa.app_connector_groups.get_connector_group('999999')
            ... if err:
            ...     print(f"Error fetching group by ID: {err}")
            ...     return
            ... print(f"Fetched group by ID: {fetched_group.as_dict()}")
        """
        http_method = "get".upper()
        api_url = format_url(f"""{
            self._zpa_base_endpoint}
            /appConnectorGroup/{group_id}
        """)

        query_params = query_params or {}
        microtenant_id = query_params.get("microtenant_id", None)
        if microtenant_id:
            query_params["microtenantId"] = microtenant_id

        request, error = self._request_executor.create_request(http_method, api_url, params=query_params)
        if error:
            return (None, None, error)

        response, error = self._request_executor.execute(request, AppConnectorGroup)
        if error:
            return (None, response, error)

        try:
            result = AppConnectorGroup(self.form_response_body(response.get_body()))
        except Exception as error:
            return (None, response, error)
        return (result, response, None)

    def get_connector_group_sg(self, group_id: str, query_params: Optional[dict] = None) -> APIResult[AppConnectorGroup]:
        """
        Fetches a specific connector group by ID with server group details

        Args:
            group_id (str): The unique identifier for the connector group.
            query_params (dict, optional): Map of query parameters for the request.
                ``[query_params.microtenant_id]`` {str}: The microtenant ID, if applicable.

        Returns:
            :obj:`Tuple`: A tuple containing (AppConnectorGroup instance, Response, error).

        Examples:
            >>> fetched_group, _, err = client.zpa.app_connector_groups.get_connector_group_sg('999999')
            ... if err:
            ...     print(f"Error fetching group by ID: {err}")
            ...     return
            ... print(f"Fetched group by ID: {fetched_group.as_dict()}")
        """
        http_method = "get".upper()
        api_url = format_url(f"""{
            self._zpa_base_endpoint}
            /appConnectorGroup/{group_id}/sg
        """)

        query_params = query_params or {}
        microtenant_id = query_params.get("microtenant_id", None)
        if microtenant_id:
            query_params["microtenantId"] = microtenant_id

        request, error = self._request_executor.create_request(http_method, api_url, params=query_params)
        if error:
            return (None, None, error)

        response, error = self._request_executor.execute(request, AppConnectorGroup)
        if error:
            return (None, response, error)

        try:
            result = AppConnectorGroup(self.form_response_body(response.get_body()))
        except Exception as error:
            return (None, response, error)
        return (result, response, None)

    def add_connector_group(self, **kwargs) -> APIResult[AppConnectorGroup]:
        """
        Adds a new ZPA App Connector Group.

        Args:
            name (str): The name of the App Connector Group.
            latitude (int): The latitude representing the App Connector's physical location.
            location (str): The name of the location that the App Connector Group represents.
            longitude (int): The longitude representing the App Connector's physical location.

        Keyword Args:
            **connector_ids (list):
                The unique ids for the App Connectors that will be added to this App Connector Group.
            **city_country (str):
                The City and Country for where the App Connectors are located. Format is:

                ``<City>, <Country Code>`` e.g. ``Sydney, AU``
            **country_code (str):
                The ISO<std> Country Code that represents the country where the App Connectors are located.
            **description (str):
                Additional information about the App Connector Group.
            **dns_query_type (str):
                The type of DNS queries that are enabled for this App Connector Group. Accepted values are:
                ``IPV4_IPV6``, ``IPV4`` and ``IPV6``
            **enabled (bool):
                Is the App Connector Group enabled? Defaults to ``True``.
            **override_version_profile (bool):
                Override the local App Connector version according to ``version_profile``. Defaults to ``False``.
            **server_group_ids (list):
                The unique ids of the Server Groups that are associated with this App Connector Group
            **lss_app_connector_group (bool):
            **upgrade_day (str):
                The day of the week that upgrades will be pushed to the App Connector.
            **upgrade_time_in_secs (str):
                The time of the day that upgrades will be pushed to the App Connector.
            **version_profile (str):
                The version profile to use. This will automatically set ``override_version_profile`` to True.
                Accepted values are:
                ``default``, ``previous_default`` and ``new_release``
            **enrollment_cert_id (str):
                ID of the enrollment certificate used for App Connector enrollment. Required by the ZPA API.
                If not provided, the SDK looks up the ``Connector`` enrollment certificate via
                ``client.zpa.enrollment_certificates.list_enrolment(query_params={"search": "Connector"})``
                and sends its ID. Pass it explicitly to use a different certificate.

        Returns:
            :obj:`Tuple`: A tuple containing (AppConnectorGroup, Response, error)

        Examples:
            >>> added_group, _, err = client.zpa.app_connector_groups.add_connector_group(
            ...     name=f"NewAppConnectorgroup_{random.randint(1000, 10000)}",
            ...     description=f"NewAppConnectorgroup_{random.randint(1000, 10000)}",
            ...     enabled= True,
            ...     city_country= "San Jose, US",
            ...     country_code= "US",
            ...     latitude= "37.3382082",
            ...     longitude= "-121.8863286",
            ...     location= "San Jose, CA, USA",
            ...     upgrade_day= "SUNDAY",
            ...     dns_query_type= "IPV4_IPV6",
            ...     enrollment_cert_id= "1234567890",
            ... )
            ... if err:
            ...     print(f"Error creating connector group: {err}")
            ...     return
            ... print(f"connector group created successfully: {added_group.as_dict()}")
        """
        http_method = "post".upper()
        api_url = format_url(f"""{
            self._zpa_base_endpoint}
            /appConnectorGroup
        """)

        body = kwargs

        microtenant_id = body.get("microtenant_id", None)
        params = {"microtenantId": microtenant_id} if microtenant_id else {}

        if not body.get("enrollment_cert_id"):
            cert, _, error = self._enrollment_certificates.get_enrolment_by_name("Connector")
            if error:
                return (None, None, error)
            body["enrollment_cert_id"] = cert.id

        # Create the request
        request, error = self._request_executor.create_request(http_method, api_url, body=body, params=params)
        if error:
            return (None, None, error)

        # Execute the request
        response, error = self._request_executor.execute(request, AppConnectorGroup)
        if error:
            return (None, response, error)

        try:
            result = AppConnectorGroup(self.form_response_body(response.get_body()))
        except Exception as error:
            return (None, response, error)
        return (result, response, None)

    def update_connector_group(self, group_id: str, **kwargs) -> APIResult[AppConnectorGroup]:
        """
        Updates an existing ZPA App Connector Group.

        Args:
            group_id (str): The unique id for the App Connector Group in ZPA.

        Keyword Args:
            **connector_ids (list):
                The unique ids for the App Connectors that will be added to this App Connector Group.
            **city_country (str):
                The City and Country for where the App Connectors are located. Format is:

                ``<City>, <Country Code>`` e.g. ``Sydney, AU``
            **country_code (str):
                The ISO<std> Country Code that represents the country where the App Connectors are located.
            **description (str):
                Additional information about the App Connector Group.
            **dns_query_type (str):
                The type of DNS queries that are enabled for this App Connector Group. Accepted values are:
                ``IPV4_IPV6``, ``IPV4`` and ``IPV6``
            **enabled (bool):
                Is the App Connector Group enabled? Defaults to ``True``.
            **name (str): The name of the App Connector Group.
            **latitude (int): The latitude representing the App Connector's physical location.
            **location (str): The name of the location that the App Connector Group represents.
            **longitude (int): The longitude representing the App Connector's physical location.
            **override_version_profile (bool):
                Override the local App Connector version according to ``version_profile``. Defaults to ``False``.
            **server_group_ids (list):
                The unique ids of the Server Groups that are associated with this App Connector Group
            **lss_app_connector_group (bool):
            **upgrade_day (str):
                The day of the week that upgrades will be pushed to the App Connector.
            **upgrade_time_in_secs (str):
                The time of the day that upgrades will be pushed to the App Connector.
            **version_profile (str):
                The version profile to use. This will automatically set ``override_version_profile`` to True.
                Accepted values are:

                ``default``, ``previous_default`` and ``new_release``
            **enrollment_cert_id (str):
                ID of the enrollment certificate used for App Connector enrollment. Required by the ZPA API.
                If not provided, the SDK looks up the ``Connector`` enrollment certificate via
                ``client.zpa.enrollment_certificates.list_enrolment(query_params={"search": "Connector"})``
                and sends its ID. Pass it explicitly to keep a different certificate.

        Returns:
            tuple: A tuple containing (AppConnectorGroup, Response, error)

            >>> update_group, _, err = client.zpa.app_connector_groups.update_connector_group(
            ...     name=f"UpdateAppConnectorgroup_{random.randint(1000, 10000)}",
            ...     description=f"UpdateAppConnectorgroup_{random.randint(1000, 10000)}",
            ...     enabled= True,
            ...     city_country= "San Jose, US",
            ...     country_code= "US",
            ...     latitude= "37.3382082",
            ...     longitude= "-121.8863286",
            ...     location= "San Jose, CA, USA",
            ...     upgrade_day= "SUNDAY",
            ...     dns_query_type= "IPV4_IPV6",
            ...     enrollment_cert_id= "1234567890",
            ... )
            ... if err:
            ...     print(f"Error creating connector group: {err}")
            ...     return
            ... print(f"connector group created successfully: {new_portal.as_dict()}")
        """
        http_method = "put".upper()
        api_url = format_url(f"""
            {self._zpa_base_endpoint}
            /appConnectorGroup/{group_id}
        """)

        body = {}

        body.update(kwargs)

        microtenant_id = body.get("microtenant_id", None)
        params = {"microtenantId": microtenant_id} if microtenant_id else {}

        if not body.get("enrollment_cert_id"):
            cert, _, error = self._enrollment_certificates.get_enrolment_by_name("Connector")
            if error:
                return (None, None, error)
            body["enrollment_cert_id"] = cert.id

        request, error = self._request_executor.create_request(http_method, api_url, body, {}, params)
        if error:
            return (None, None, error)

        # Execute the request
        response, error = self._request_executor.execute(request, AppConnectorGroup)
        if error:
            return (None, response, error)

        if response is None or not response.get_body():
            return (AppConnectorGroup({"id": group_id}), response, None)

        try:
            result = AppConnectorGroup(self.form_response_body(response.get_body()))
        except Exception as error:
            return (None, response, error)
        return (result, response, None)

    def delete_connector_group(self, group_id: str, microtenant_id: Optional[str] = None) -> APIResult[None]:
        """
        Deletes the specified App Connector Group from ZPA.

        Args:
            group_id (str): The unique identifier for the App Connector Group.
            microtenant_id (str, optional): The optional ID of the microtenant if applicable.

        Returns:
            tuple: A tuple containing the response and error (if any).

        Examples:
            >>> _, _, err = client.zpa.app_connector_groups.delete_connector_group(
            ...     group_id='999999'
            ... )
            ... if err:
            ...     print(f"Error deleting app connector group: {err}")
            ...     return
            ... print(f"app connector group with ID {'999999'} deleted successfully.")
        """
        http_method = "delete".upper()
        api_url = format_url(f"""
            {self._zpa_base_endpoint}
            /appConnectorGroup/{group_id}
        """)

        params = {"microtenantId": microtenant_id} if microtenant_id else {}

        request, error = self._request_executor.create_request(http_method, api_url, params=params)
        if error:
            return (None, None, error)

        response, error = self._request_executor.execute(request)
        if error:
            return (None, response, error)

        return (None, response, None)
