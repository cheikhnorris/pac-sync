"""
Copyright (c) 2023, Zscaler Inc.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"""

from zscaler.oneapi_collection import ZscalerCollection
from zscaler.oneapi_object import ZscalerObject


class ApplicationFederation(ZscalerObject):
    """
    A class representing a ApplicationFederation object.
    """

    def __init__(self, config=None):
        super().__init__(config)
        if config:
            self.application_gid = config["applicationGid"] if "applicationGid" in config else None
            self.guest_ids = ZscalerCollection.form_list(config["guestIds"] if "guestIds" in config else [], str)
            self.message = config["message"] if "message" in config else None
        else:
            self.application_gid = None
            self.guest_ids = []
            self.message = None

    def request_format(self):
        """
        Return the object as a dictionary in the format expected for API requests.
        """
        parent_req_format = super().request_format()
        current_obj_format = {
            "applicationGid": self.application_gid,
            "guestIds": self.guest_ids,
            "message": self.message,
        }
        parent_req_format.update(current_obj_format)
        return parent_req_format


class ApplicationFederationRequest(ZscalerObject):
    """
    A class representing a ApplicationFederationRequest object.
    """

    def __init__(self, config=None):
        super().__init__(config)
        if config:
            self.application_gid = config["applicationGid"] if "applicationGid" in config else None
            self.guest_gids = ZscalerCollection.form_list(config["guestGids"] if "guestGids" in config else [], str)
        else:
            self.application_gid = None
            self.guest_gids = []

    def request_format(self):
        """
        Return the object as a dictionary in the format expected for API requests.
        """
        parent_req_format = super().request_format()
        current_obj_format = {
            "applicationGid": self.application_gid,
            "guestGids": self.guest_gids,
        }
        parent_req_format.update(current_obj_format)
        return parent_req_format
