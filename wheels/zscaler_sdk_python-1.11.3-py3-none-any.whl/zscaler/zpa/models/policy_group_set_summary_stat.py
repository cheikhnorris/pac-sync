"""
Copyright (c) 2023, Zscaler Inc.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"""

from typing import Any, Dict, Optional

from zscaler.oneapi_object import ZscalerObject


class PolicyGroupSetSummaryStat(ZscalerObject):
    """
    A class for PolicyGroupSetSummaryStat objects.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """
        Initialize the PolicyGroupSetSummaryStat model based on API response.

        Args:
            config (dict): A dictionary representing the configuration.
        """
        super().__init__(config)

        if config:
            self.disabled_rules = config["disabledRules"] if "disabledRules" in config else None
            self.enabled_rules = config["enabledRules"] if "enabledRules" in config else None
            self.total_policy_groups = config["totalPolicyGroups"] if "totalPolicyGroups" in config else None
            self.total_rules = config["totalRules"] if "totalRules" in config else None
        else:
            self.disabled_rules = None
            self.enabled_rules = None
            self.total_policy_groups = None
            self.total_rules = None

    def request_format(self) -> Dict[str, Any]:
        """
        Return the object as a dictionary in the format expected for API requests.
        """
        parent_req_format = super().request_format()
        current_obj_format = {
            "disabledRules": self.disabled_rules,
            "enabledRules": self.enabled_rules,
            "totalPolicyGroups": self.total_policy_groups,
            "totalRules": self.total_rules,
        }
        parent_req_format.update(current_obj_format)
        return parent_req_format
