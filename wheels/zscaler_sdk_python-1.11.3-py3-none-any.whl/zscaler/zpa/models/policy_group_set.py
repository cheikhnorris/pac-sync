"""
Copyright (c) 2023, Zscaler Inc.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"""

from typing import Any, Dict, Optional

from zscaler.oneapi_collection import ZscalerCollection
from zscaler.oneapi_object import ZscalerObject


class PolicyGroupSet(ZscalerObject):
    """
    A class for PolicyGroupSet objects.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """
        Initialize the PolicyGroupSet model based on API response.

        Args:
            config (dict): A dictionary representing the configuration.
        """
        super().__init__(config)

        if config:
            self.creation_time = config["creationTime"] if "creationTime" in config else None
            self.default_policy_group_gid = config["defaultPolicyGroupGid"] if "defaultPolicyGroupGid" in config else None
            self.global_policy_group_gid = config["globalPolicyGroupGid"] if "globalPolicyGroupGid" in config else None
            self.id = config["id"] if "id" in config else None
            self.modified_by = config["modifiedBy"] if "modifiedBy" in config else None
            self.modified_time = config["modifiedTime"] if "modifiedTime" in config else None
            self.name = config["name"] if "name" in config else None
            self.policy_type = config["policyType"] if "policyType" in config else None
            self.microtenant_id = config["microtenantId"] if "microtenantId" in config else None
            self.microtenant_name = config["microtenantName"] if "microtenantName" in config else None
            self.custom_policy_group_gids = ZscalerCollection.form_list(
                config["customPolicyGroupGids"] if "customPolicyGroupGids" in config else [], int
            )
        else:
            self.creation_time = None
            self.default_policy_group_gid = None
            self.global_policy_group_gid = None
            self.id = None
            self.modified_by = None
            self.modified_time = None
            self.name = None
            self.policy_type = None
            self.microtenant_id = None
            self.microtenant_name = None
            self.custom_policy_group_gids = []

    def request_format(self) -> Dict[str, Any]:
        """
        Return the object as a dictionary in the format expected for API requests.
        """
        parent_req_format = super().request_format()
        current_obj_format = {
            "creationTime": self.creation_time,
            "defaultPolicyGroupGid": self.default_policy_group_gid,
            "globalPolicyGroupGid": self.global_policy_group_gid,
            "id": self.id,
            "modifiedBy": self.modified_by,
            "modifiedTime": self.modified_time,
            "name": self.name,
            "policyType": self.policy_type,
            "microtenantId": self.microtenant_id,
            "microtenantName": self.microtenant_name,
            "customPolicyGroupGids": self.custom_policy_group_gids,
        }
        parent_req_format.update(current_obj_format)
        return parent_req_format
