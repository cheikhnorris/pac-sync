"""
Copyright (c) 2023, Zscaler Inc.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
"""

from typing import Any, Dict, Optional

from zscaler.oneapi_object import ZscalerObject


class VZenNodes(ZscalerObject):
    """
    A class for VZenNodes objects.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """
        Initialize the VZenNodes model based on API response.

        Args:
            config (dict): A dictionary representing the configuration.
        """
        super().__init__(config)

        if config:
            self.id = config["id"] if "id" in config else None
            self.zgateway_id = config["zgatewayId"] if "zgatewayId" in config else None
            self.name = config["name"] if "name" in config else None
            self.status = config["status"] if "status" in config else None
            self.in_production = config["inProduction"] if "inProduction" in config else None
            self.ip_address = config["ipAddress"] if "ipAddress" in config else None
            self.subnet_mask = config["subnetMask"] if "subnetMask" in config else None
            self.default_gateway = config["defaultGateway"] if "defaultGateway" in config else None
            self.type = config["type"] if "type" in config else None
            self.ip_sec_enabled = config["ipSecEnabled"] if "ipSecEnabled" in config else None
            self.on_demand_support_tunnel_enabled = (
                config["onDemandSupportTunnelEnabled"] if "onDemandSupportTunnelEnabled" in config else None
            )
            self.establish_support_tunnel_enabled = (
                config["establishSupportTunnelEnabled"] if "establishSupportTunnelEnabled" in config else None
            )
            self.load_balancer_ip_address = config["loadBalancerIpAddress"] if "loadBalancerIpAddress" in config else None
            self.deployment_mode = config["deploymentMode"] if "deploymentMode" in config else None
            self.cluster_name = config["clusterName"] if "clusterName" in config else None
            self.vzen_sku_type = config["vzenSkuType"] if "vzenSkuType" in config else None
        else:
            self.id = None
            self.zgateway_id = None
            self.name = None
            self.status = None
            self.in_production = None
            self.ip_address = None
            self.subnet_mask = None
            self.default_gateway = None
            self.type = None
            self.ip_sec_enabled = None
            self.on_demand_support_tunnel_enabled = None
            self.establish_support_tunnel_enabled = None
            self.load_balancer_ip_address = None
            self.deployment_mode = None
            self.cluster_name = None
            self.vzen_sku_type = None

    def request_format(self) -> Dict[str, Any]:
        """
        Return the object as a dictionary in the format expected for API requests.
        """
        parent_req_format = super().request_format()
        current_obj_format = {
            "id": self.id,
            "zgatewayId": self.zgateway_id,
            "name": self.name,
            "status": self.status,
            "inProduction": self.in_production,
            "ipAddress": self.ip_address,
            "subnetMask": self.subnet_mask,
            "defaultGateway": self.default_gateway,
            "type": self.type,
            "ipSecEnabled": self.ip_sec_enabled,
            "onDemandSupportTunnelEnabled": self.on_demand_support_tunnel_enabled,
            "establishSupportTunnelEnabled": self.establish_support_tunnel_enabled,
            "loadBalancerIpAddress": self.load_balancer_ip_address,
            "deploymentMode": self.deployment_mode,
            "clusterName": self.cluster_name,
            "vzenSkuType": self.vzen_sku_type,
        }
        parent_req_format.update(current_obj_format)
        return parent_req_format
